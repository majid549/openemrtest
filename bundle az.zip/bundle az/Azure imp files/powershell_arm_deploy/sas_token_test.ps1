﻿#Login-AzureRmAccount
#Save-AzureRmProfile -Path “C:\Users\saurghos\Documents\Visual Studio 2015\azurermcreds\manjucreds.json"
Select-AzureRmProfile -Path “C:\Users\saurghos\Documents\Visual Studio 2015\azurermcreds\manjucreds.json”
$resourcegroup = "test-rg"
$storageaccname = "myteststor123"
$location = "North Europe"
$resourcegroupdeploymentname = "testDeploy"
Set-AzureRmCurrentStorageAccount -ResourceGroupName $resourcegroup -Name $storageaccname
$templateuri = New-AzureStorageBlobSASToken -Container uploads `
-Blob collect_vm_master.json -Permission r -ExpiryTime (Get-Date).AddHours(2.0) -FullUri
#---- in case there is a param file for the master template ----
#$templateparamuri = New-AzureStorageBlobSASToken -Container uploads `
#-Blob collect_vm_master.parameters.json -Permission r -ExpiryTime (Get-Date).AddHours(2.0) -FullUri
#---- end ----
New-AzureRmResourceGroupDeployment -Name $resourcegroupdeploymentname -ResourceGroupName $resourcegroup -TemplateUri $templateuri
#-TemplateFile $templateuri -TemplateParameterFile $tempparamfilelocation