﻿Select-AzureRmProfile -Path “C:\Users\saurghos\Documents\Visual Studio 2015\azurermcreds\manjucreds.json"
$Keys = Get-AzureRmStorageAccountKey -ResourceGroupName "test-rg" -Name "myteststor123"
$StorageContext = New-AzureStorageContext -StorageAccountName "myteststor123" -StorageAccountKey $Keys[0].Value
#New-AzureStorageContainer -Context $StorageContext -Name uploads
$UploadFile = @{
    Context = $StorageContext;
    Container = 'uploads';
    #File = "C:\Users\saurghos\Documents\Visual Studio 2015\Projects\SingleVMExistingSA\SingleVMExistingSA\Templates\SingleVMExistingSA.json";
    #File = "C:\Users\saurghos\Documents\Visual Studio 2015\Projects\SingleVMExistingSA\SingleVMExistingSA\Templates\SingleVMExistingSA.parameters.json";
    #File = "C:\Users\saurghos\Documents\Visual Studio 2015\Projects\SingleVMWithDataDiskStaticIP\SingleVMWithDataDiskStaticIP\Templates\SingleVMWithDataDiskStaticIP.json";
    #File = "C:\Users\saurghos\Documents\Visual Studio 2015\Projects\SingleVMWithDataDiskStaticIP\SingleVMWithDataDiskStaticIP\Templates\SingleVMWithDataDiskStaticIP.parameters.json";
    #File = "C:\Users\saurghos\Documents\Visual Studio 2015\Projects\SingleVMWithDataDisk\SingleVMWithDataDisk\Templates\SingleVMWithDataDisk.json";
    #File = "C:\Users\saurghos\Documents\Visual Studio 2015\Projects\SingleVMWithDataDisk\SingleVMWithDataDisk\Templates\SingleVMWithDataDisk.parameters.json";
    #File = "C:\Users\saurghos\Documents\Visual Studio 2015\Projects\Collect_VM_master\Collect_VM_master\Templates\collect_vm_master.json";
    #File = "C:\Users\saurghos\Desktop\new params\SVMExistingSA3.parameters.json";
    File = "C:\Users\saurghos\Documents\Visual Studio 2015\Projects\Collect_VM_master\Collect_VM_master\Templates\collect_vm_master.parameters.json";
    }
Set-AzureStorageBlobContent @UploadFile;