﻿#Check Available IP addresses
Select-AzureRmProfile -Path "C:\Users\saurghos\Documents\Visual Studio 2015\azurermcreds\azureprofile_dfe.json"
#Get-AzureRmSubscription –SubscriptionName "DFE T2 Capgemini Sandpit" | Select-AzureSubscription
$RG = "rg-sandpit-core"
$VNetName = "vnet-core"
$vnet = Get-AzureRmVirtualNetwork -Name $VNetName -ResourceGroupName $RG
$networkID = "172.30.31."
For ($i=1; $i -lt 33; $i++) 
{
    $IP = $networkID + $i
    $Address = Test-AzureStaticVNetIP -VNetName $vnet -IPAddress $IP
    If ($Address.IsAvailable –eq $False) { Write-Host "$IP is not available" -ForegroundColor Red } `
    else { Write-Host "$IP is available" -ForegroundColor Green}
}