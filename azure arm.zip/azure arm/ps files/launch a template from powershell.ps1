﻿#Login-AzureRmAccount
#Set-AzureRmContext -SubscriptionID <YourSubscriptionId>
#Save-AzureRmProfile -Path “C:\Users\saurghos\Documents\Visual Studio 2015\azurermcreds\azureprofile.json”
cls
#Select-AzureRmProfile -Path “C:\Users\saurghos\Documents\Visual Studio 2015\azurermcreds\azureprofile_old.json”
$resourcegroup = "newRG"
$location = "South India"
$resourcegroupdeploymentname = "CollectDeploy"
$tempfilelocation = "D:\Users\mkhan28\Desktop\tempp\aaa.json"
$tempparamfilelocation = "D:\Users\mkhan28\Desktop\tempp\aaa.parameters.json"
#New-AzureRmResourceGroup -Name $resourcegroup -Location $location
New-AzureRmResourceGroupDeployment -Name $resourcegroupdeploymentname -ResourceGroupName $resourcegroup `
-TemplateFile $tempfilelocation `
-TemplateParameterFile $tempparamfilelocation -Verbose -Force
