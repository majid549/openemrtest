﻿Login-AzureRMAccount
Save-AzureRmProfile -Path “C:\Users\saurghos\Documents\Visual Studio 2015\azurermcreds\azureprofile_dfe.json”
Select-AzureRmProfile -Path "C:\Users\saurghos\Documents\Visual Studio 2015\azurermcreds\azureprofile_dfe.json"
#Select-AzureRmSubscription -SubscriptionID "bd1a7375-18a6-4fcb-ad3f-95542caa3e25"
#Get-AzureRmVM -ResourcegroupName "rg-sandpit-dev" -Name "vm-dev-dev20"
# Adding PS Snapin

$snapin = Get-PSSnapin | Where-Object {$_.Name -eq ‘Microsoft.SharePoint.Powershell’}

if ($snapin -eq $null)

{

   Write-Host “Loading SharePoint Powershell Snapin” -ForegroundColor Green

    Add-PSSnapin “Microsoft.SharePoint.Powershell”

}

# This is a common function i am using which will release excel objects

function Release-Ref ($ref) {

([System.Runtime.InteropServices.Marshal]::ReleaseComObject(

[System.__ComObject]$ref) -gt 0)

[System.GC]::Collect()

[System.GC]::WaitForPendingFinalizers()

}

Foreach ($resource in Get-AzureRmResourceGroup){

# Creating excel object


    $excel = new-object -comobject Excel.Application
    $wb = $excel.Workbooks("C:\Users\saurghos\Desktop\Inventory_data.xlsm")
    $ws1 = $wb.Worksheets(1)
    $xlRow = $ws1.Range("A2").End(xlDown).Row
    Write-Host $wb.author
     

}

