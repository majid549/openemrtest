﻿#Login-AzureRmAccount
#Set-AzureRmContext -SubscriptionID <YourSubscriptionId>
#Save-AzureRmProfile -Path “C:\Users\saurghos\Documents\Visual Studio 2015\azurermcreds\azureprofile.json”
Select-AzureRmProfile -Path “C:\Users\saurghos\Documents\Visual Studio 2015\azurermcreds\azureprofile_old.json”
$resourcegroup = "rg-subscription-shared"
$location = "North Europe"
$resourcegroupdeploymentname = "CollectDeploy"
$tempfilelocation = "https://stustrg19943.blob.core.windows.net/uploads/collect_vm_master.json"
#$tempparamfilelocation = "C:\Users\saurghos\Documents\Visual Studio 2015\Projects\MultiVMwithDD\MultiVMwithDD\Templates\mvmdd.parameters.json"
#New-AzureRmResourceGroup -Name $resourcegroup -Location $location
New-AzureRmResourceGroupDeployment -Name $resourcegroupdeploymentname -ResourceGroupName $resourcegroup `
-TemplateFile $tempfilelocation
#-TemplateParameterFile $tempparamfilelocation
