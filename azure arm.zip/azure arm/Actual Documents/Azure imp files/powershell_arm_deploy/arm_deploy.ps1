﻿#Login-AzureRmAccount
#Set-AzureRmContext -SubscriptionID <YourSubscriptionId>
#Save-AzureRmProfile -Path “C:\Users\saurghos\Documents\Visual Studio 2015\azurermcreds\azureprofile.json”

#Select-AzureRmProfile -Path "C:\Users\saurghos\Documents\Visual Studio 2015\azurermcreds\azureprofile.json"
#Select-AzureRmSubscription -SubscriptionID "bd1a7375-18a6-4fcb-ad3f-95542caa3e25"
#Create a variable to store the Storage Account name
$StorageAccount = 'myscriptsstorage'
#Save the storage account key
#$StorageKey = (Get-AzureStorageKey -StorageAccountName $StorageAccount).Primary
$StorageKey = "CcKr7s5sUjVROtj5xk9/HSEFU2XGU+sKPKXpNMAFH50tKqeeIvzYyfNtLEp6i+etFlVdS4girayv+Kxi9VFhdA=="
#Create a context to the storage account
$ctx = new-azurestoragecontext -storageaccountname $StorageAccount -storageaccountkey $StorageKey

$tempfilelocation = Get-AzureStorageFile `
–Context $ctx –Path "https://myscriptsstorage.file.core.windows.net/scripts/azuredeploy.json"
$tempparamfilelocation = Get-AzureStorageFile `
–Context $ctx –Path "https://myscriptsstorage.file.core.windows.net/scripts/azuredeploy.parameters.json"
$resourcegroup = "collect-dev-rg"
$location = "Southeast Asia"
$resourcegroupdeploymentname = "CollectDevDeployment"
New-AzureRmResourceGroup -Name $resourcegroup -Location $location
New-AzureRmResourceGroupDeployment -Name $resourcegroupdeploymentname -ResourceGroupName $resourcegroup `
-TemplateFile $tempfilelocation -TemplateParameterFile $tempparamfilelocation
###############################################################################################

Select-AzureRmProfile -Path "C:\Users\saurghos\Documents\Visual Studio 2015\azurermcreds\azureprofile.json"
$StorageAccount = 'myscriptsstorage'
$StorageKey = "CcKr7s5sUjVROtj5xk9/HSEFU2XGU+sKPKXpNMAFH50tKqeeIvzYyfNtLEp6i+etFlVdS4girayv+Kxi9VFhdA=="
$ctx = New-AzureStorageContext -storageaccountname $StorageAccount -storageaccountkey $StorageKey
$s = Get-AzureStorageShare scripts -Context $ctx
$tempfilelocation = Get-AzureStorageFile -Share $s -Path "azuredeploy.json"
$tempparamfilelocation = Get-AzureStorageFile -Share $s -Path "azuredeploy.parameters.json"
$resourcegroup = "collect-dev-rg1"
$location = "Southeast Asia"
$resourcegroupdeploymentname = "CollectDevDeployment"
New-AzureRmResourceGroup -Name $resourcegroup -Location $location
#New-AzureRmResourceGroupDeployment -ResourceGroupName $resourcegroup -TemplateFile $tempfilelocation -TemplateParameterFile $tempparamfilelocation
New-AzureRmResourceGroupDeployment -ResourceGroupName $resourcegroup -TemplateFile $tempfilelocation `
-TemplateParameterFile $tempparamfilelocation -Force -Mode Incremental -Name $resourcegroupdeploymentname
#-StorageAccountName $StorageAccount

#################################################################################################